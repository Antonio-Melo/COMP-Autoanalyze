#ifndef GLUTRENDER_H
#define	GLUTRENDER_H


#ifdef __cplusplus
extern "C" {
#endif

    int cb_glutinit(int x,int y,int w,int h, int bits,int s_rate,int fullscreen,int* argcp, char *argv[],char* optArg);

#ifdef __cplusplus
}				/* end extern "C" */
#endif
#endif
