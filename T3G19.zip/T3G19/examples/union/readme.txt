**Operation:
Union of two automata

**Description:
In this example we have the input files inputGraph1 and inputGraph2,
both .dot files, and what our tool does is outputting the result of
the union operation on these two automata to a file 
denominated outputGraph, with the final graph result written in 
dot language. It also generates the image outputGraph (.png format)
equivalent to the output .dot file.  