**Operation: 
Reversal of an automata

**Description:
In this example we have as input file the file inputGraph.dot, 
a dot language file representing an automata.
Our tool outputs the result of the reversal operation to a file 
denominated outputGraph.dot. This operation on making the automata accept
the strings in the reverse order. 
It also represents this outputGraph in image format,
outputGraph.png.