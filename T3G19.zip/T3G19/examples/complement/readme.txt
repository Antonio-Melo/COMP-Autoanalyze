**Operation: 
Complement of an automata

**Description:
In this example we have as input file the file inputGraph.dot, 
a dot language file representing an automata.
Our tool outputs the result of the complement operation to a file 
denominated outputGraph.dot. This operation consists on toggling all
the accepting states. It also represents this outputGraph in image format,
outputGraph.png.
